// アプリケーション作成用のモジュールを読み込み
'use strict';
const {app, Menu, dialog, BrowserWindow} = require("electron");

// メインウィンドウ
let mainWindow;
var force_quit = false;

function createWindow() {
    // メインウィンドウを作成
    mainWindow = new BrowserWindow({
        width: 1024,
        height: 768,
        icon: 'icon/icon.icns',
        webPreferences: {
            nodeIntegration: true
        }
    });

    // メインウィンドウに表示するURLを指定します
    // （今回はmain.jsと同じディレクトリのindex.html）
    mainWindow.loadFile("index.html");

    // デベロッパーツールの起動
    // mainWindow.webContents.openDevTools();

    // メインウィンドウが閉じられたときの処理
    // mainWindow.on("closed", () => {
    //     console.log("window-all-closed");
    //     mainWindow = null;
    // });

    mainWindow.on('close', function (e) {
        console.log("close");
        if (!force_quit) {
            e.preventDefault();
            mainWindow.hide();
        }
    });

    app.on('activate', function () {
        console.log("reactive");
        mainWindow.show();
    });
    app.on('before-quit', function (e) {
        // Handle menu-item or keyboard shortcut quit here
        console.log("before-quit");
        force_quit = true;
    });
}

//  初期化が完了した時の処理
app.on("ready", createWindow);

// 全てのウィンドウが閉じたときの処理
app.on("window-all-closed", () => {
    // macOSのとき以外はアプリケーションを終了させます
    if (process.platform !== "darwin") {
        app.quit();
    }
});

// アプリケーションがアクティブになった時の処理（Macだと、Dockがクリックされた時）
app.on("activate", () => {
    // メインウィンドウが消えている場合は再度メインウィンドウを作成する
    if (mainWindow === null) {
        createWindow();
    }
});

const templateMenu = [
    {
        label: 'Edit',
        submenu: [
            {
                role: 'undo',
            },
            {
                role: 'redo',
            },
        ]
    },
    {
        label: 'View',
        submenu: [
            {
                role: 'resetzoom',
            },
            {
                role: 'zoomin',
            },
            {
                role: 'zoomout',
            },
            {
                type: 'separator',
            },
            {
                role: 'togglefullscreen',
            },
            {
                type: 'separator',
            },
            {
                label: 'Inspection',
                accelerator: 'CmdOrCtrl+i',
                click(item, focusedWindow) {
                    if (focusedWindow) focusedWindow.webContents.openDevTools();
                },
            },

        ],
    }
];

const menu = Menu.buildFromTemplate(templateMenu);
Menu.setApplicationMenu(menu);
